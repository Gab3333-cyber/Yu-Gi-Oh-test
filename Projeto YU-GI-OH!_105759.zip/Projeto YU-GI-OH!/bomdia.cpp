#include <iostream>
using namespace std;

int main() {
    cout << "Bom dia";
    return 0;

}


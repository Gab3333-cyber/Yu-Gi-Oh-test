#include "efeitoDiminuirATK.h"

EfeitoDiminuirATK::EfeitoDiminuirATK(int diminuicao) : diminuicao(diminuicao) {}

void EfeitoDiminuirATK::aplicar(Carta& carta) {
    carta.atk -= diminuicao;
}

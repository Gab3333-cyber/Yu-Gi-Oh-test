#include "zona.h"

Zona::Zona() : carta(nullptr) {}

void Zona::reiniciarZona() {
    carta = nullptr;
}

bool Zona::vazia() const {
    return carta == nullptr;
}

#ifndef JOGO_H
#define JOGO_H

#include "jogador.h"
#include <set>

class Jogo {
public:
    Jogador jogador1;
    Jogador jogador2;
    int jogadorAtual;
    int turno;
    std::set<int> monstrosAtacaram;

    Jogo();
    void executar();
    void finalizarTurno();
    void invocarMonstro();
    void trocarPosicaoMonstro();
    void ativarEfeito();
    void ativarAtaque();
};

#endif // JOGO_H

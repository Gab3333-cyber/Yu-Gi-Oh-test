#ifndef ZONA_H
#define ZONA_H

#include "carta.h"

class Zona {
public:
    Carta* carta;

    Zona();
    void reiniciarZona();
    bool vazia() const;
};

#endif // ZONA_H

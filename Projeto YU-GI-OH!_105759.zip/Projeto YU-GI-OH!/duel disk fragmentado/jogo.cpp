#include "jogo.h"
#include <iostream>

Jogo::Jogo() : jogadorAtual(1), turno(1) {}

void Jogo::executar() {
    while (jogador1.pontosVida > 0 && jogador2.pontosVida > 0) {
        std::cout << "Turno do Jogador " << jogadorAtual << std::endl;
        jogadorAtual == 1 ? jogador1.exibirCampo(jogadorAtual) : jogador2.exibirCampo(jogadorAtual);
        std::cout << "Mao do Jogador " << jogadorAtual << std::endl;
        jogadorAtual == 1 ? jogador1.exibirMao() : jogador2.exibirMao();

        std::string fase;
        if (turno == 1) {
            std::cout << "Fase de Compra. Pressione n para a proxima fase: ";
            std::cin >> fase;
            if (fase == "n") {
                if (jogadorAtual == 1) {
                    jogador1.comprarCarta();
                } else {
                    jogador2.comprarCarta();
                }
                turno++;
            }
            continue;
        } else {
            std::cout << "Escolha a fase: m1 (Main Phase 1), b (Battle Phase), m2 (Main Phase 2), e (End Phase): ";
            std::cin >> fase;

            if (fase == "m1" || fase == "m2") {
                std::string acao;
                std::cout << "Escolha a acao: i (invocar), p (trocar posicao), a (ativar efeito), n (proxima fase): ";
                std::cin >> acao;

                if (acao == "i") {
                    invocarMonstro();
                } else if (acao == "p") {
                    trocarPosicaoMonstro();
                } else if (acao == "a") {
                    ativarEfeito();
                } else if (acao == "n") {
                    if (fase == "m1") {
                        continue;
                    } else {
                        finalizarTurno();
                    }
                }
            } else if (fase == "b") {
                ativarAtaque();
            } else if (fase == "e") {
                finalizarTurno();
            }
        }
    }

    std::cout << "Jogo encerrado!" << std::endl;
}

void Jogo::finalizarTurno() {
    jogadorAtual = (jogadorAtual == 1) ? 2 : 1;
    turno++;
    monstrosAtacaram.clear();
    if (jogadorAtual == 1) {
        jogador1.comprarCarta();
    } else {
        jogador2.comprarCarta();
    }
}

void Jogo::invocarMonstro() {
    int indiceCarta, indiceZona, faceParaBaixo;
    std::string posicao;
    std::cout << "Escolha a carta da mao para invocar (indice): ";
    std::cin >> indiceCarta;
    std::cout << "Escolha a zona do campo para invocar (indice): ";
    std::cin >> indiceZona;
    std::cout << "Escolha a posicao (ataque/defesa): ";
    std::cin >> posicao;
    std::cout << "Invocar com a face para baixo? (1 para sim, 0 para nao): ";
    std::cin >> faceParaBaixo;

    Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
    jogador.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
}

void Jogo::trocarPosicaoMonstro() {
    int indiceZona;
    std::cout << "Escolha a zona do monstro para trocar posicao (indice): ";
    std::cin >> indiceZona;

    Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
    if (indiceZona < 0 || indiceZona >= jogador.campo.size() || jogador.campo[indiceZona].carta == nullptr) {
        std::cout << "Indice de zona invalido." << std::endl;
        return;
    }

    jogador.campo[indiceZona].carta->trocarPosicao();
}

void Jogo::ativarEfeito() {
    int indiceZona;
    std::cout << "Escolha a zona do monstro para ativar efeito (indice): ";
    std::cin >> indiceZona;

    Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
    if (indiceZona < 0 || indiceZona >= jogador.campo.size() || jogador.campo[indiceZona].carta == nullptr) {
        std::cout << "Indice de zona invalido." << std::endl;
        return;
    }

    jogador.campo[indiceZona].carta->ativarEfeito();
}

void Jogo::ativarAtaque() {
    int indiceAtacante, indiceDefensor;
    std::cout << "Escolha a zona do monstro atacante (indice): ";
    std::cin >> indiceAtacante;

    Jogador& jogadorAtacante = (jogadorAtual == 1) ? jogador1 : jogador2;
    Jogador& jogadorDefensor = (jogadorAtual == 1) ? jogador2 : jogador1;

    if (indiceAtacante < 0 || indiceAtacante >= jogadorAtacante.campo.size() || jogadorAtacante.campo[indiceAtacante].carta == nullptr) {
        std::cout << "Indice de zona invalido." << std::endl;
        return;
    }

    if (monstrosAtacaram.find(indiceAtacante) != monstrosAtacaram.end()) {
        std::cout << "Este monstro ja atacou neste turno." << std::endl;
        return;
    }

    if (jogadorDefensor.todasZonasVazias()) {
        std::cout << "Nao ha monstros no campo do adversario. Ataque direto!" << std::endl;
        jogadorDefensor.pontosVida -= jogadorAtacante.campo[indiceAtacante].carta->pontosATK;
        if (jogadorDefensor.pontosVida < 0) {
            jogadorDefensor.pontosVida = 0;
        }
        std::cout << "Pontos de Vida do Jogador " << (jogadorAtual == 1 ? 2 : 1) << ": " << jogadorDefensor.pontosVida << std::endl;
        monstrosAtacaram.insert(indiceAtacante);
        return;
    }

    std::cout << "Escolha a zona do monstro defensor (indice): ";
    std::cin >> indiceDefensor;

    if (indiceDefensor < 0 || indiceDefensor >= jogadorDefensor.campo.size() || jogadorDefensor.campo[indiceDefensor].carta == nullptr) {
        std::cout << "Indice de zona invalido." << std::endl;
        return;
    }

    Carta* atacante = jogadorAtacante.campo[indiceAtacante].carta;
    Carta* defensor = jogadorDefensor.campo[indiceDefensor].carta;

    if (atacante->pontosATK > defensor->pontosDEF) {
        std::cout << atacante->nome << " (ATK: " << atacante->pontosATK << ") destruiu " << defensor->nome << " (DEF: " << defensor->pontosDEF << ")." << std::endl;
        jogadorDefensor.cemiterio.push_back(*defensor);
        jogadorDefensor.campo[indiceDefensor].reiniciarZona();
    } else if (atacante->pontosATK < defensor->pontosDEF) {
        std::cout << atacante->nome << " (ATK: " << atacante->pontosATK << ") foi destruido ao atacar " << defensor->nome << " (DEF: " << defensor->pontosDEF << ")." << std::endl;
        jogadorAtacante.cemiterio.push_back(*atacante);
        jogadorAtacante.campo[indiceAtacante].reiniciarZona();
    } else {
        std::cout << "O ataque resultou em um empate. Ambos os monstros foram destruídos." << std::endl;
        jogadorAtacante.cemiterio.push_back(*atacante);
        jogadorAtacante.campo[indiceAtacante].reiniciarZona();
        jogadorDefensor.cemiterio.push_back(*defensor);
        jogadorDefensor.campo[indiceDefensor].reiniciarZona();
    }

    monstrosAtacaram.insert(indiceAtacante);
}

#ifndef CARTA_H
#define CARTA_H

#include <string>
#include "efeito.h"

class Carta {
public:
    std::string nome;
    int pontosATK;
    int pontosDEF;
    int nivel;
    std::string posicao;
    bool faceParaBaixo;
    Efeito* efeito;

    Carta(std::string nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito = nullptr);
    void ativarEfeito();
    void trocarPosicao();
};

#endif // CARTA_H

#ifndef JOGADOR_H
#define JOGADOR_H

#include <vector>
#include "carta.h"
#include "zona.h"

class Jogador {
public:
    std::vector<Carta> mao;
    std::vector<Zona> campo;
    std::vector<Carta> cemiterio;
    std::vector<Carta> deck;
    int pontosVida;

    Jogador();
    void adicionarCartaMao(const Carta& carta);
    void exibirMao() const;
    void exibirCampo(int jogadorAtual) const;
    void invocarCarta(int indiceCarta, int indiceZona, const std::string& posicao, int faceParaBaixo);
    bool todasZonasVazias() const;
    void comprarCarta();
    void descartarCarta(int indiceCarta);
};

#endif // JOGADOR_H

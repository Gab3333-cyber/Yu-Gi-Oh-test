#include "jogo.h"

int main() {
    Jogo jogo;

    // Exemplo de inicializacao de decks
    jogo.jogador1.deck = {
        Carta("Dragão Branco de Olhos Azuis", 3000, 2500, 8),
        Carta("Dragão Negro de Olhos Vermelhos", 2400, 2000, 7),
        Carta("Mago Negro", 2500, 2100, 7, new EfeitoAumentoATK(500))
    };

    jogo.jogador2.deck = {
        Carta("Invocador das Trevas", 2000, 1700, 6, new EfeitoDiminuirATK(300)),
        Carta("Caveira Convocada", 2500, 1200, 6),
        Carta("Gigante de Pedra", 2000, 2300, 5),
    };

    jogo.jogador1.comprarCarta();
    jogo.jogador2.comprarCarta();
    jogo.jogador1.comprarCarta();
    jogo.jogador2.comprarCarta();

    jogo.executar();
    
    return 0;
}

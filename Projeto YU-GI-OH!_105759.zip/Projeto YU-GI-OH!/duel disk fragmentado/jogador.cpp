#include "jogador.h"
#include <iostream>

Jogador::Jogador() : pontosVida(8000), campo(5) {}

void Jogador::adicionarCartaMao(const Carta& carta) {
    mao.push_back(carta);
}

void Jogador::exibirMao() const {
    for (size_t i = 0; i < mao.size(); ++i) {
        std::cout << i << ": " << mao[i].nome << " (ATK: " << mao[i].pontosATK << ", DEF: " << mao[i].pontosDEF << ", Nivel: " << mao[i].nivel << ")" << std::endl;
    }
}

void Jogador::exibirCampo(int jogadorAtual) const {
    std::cout << "Campo do Jogador " << jogadorAtual << ":" << std::endl;
    for (size_t i = 0; i < campo.size(); ++i) {
        if (campo[i].carta != nullptr) {
            std::cout << "Zona " << i << ": " << campo[i].carta->nome << " (ATK: " << campo[i].carta->pontosATK << ", DEF: " << campo[i].carta->pontosDEF << ", Posicao: " << campo[i].carta->posicao << ")" << std::endl;
        } else {
            std::cout << "Zona " << i << ": [vazia]" << std::endl;
        }
    }
}

void Jogador::invocarCarta(int indiceCarta, int indiceZona, const std::string& posicao, int faceParaBaixo) {
    if (indiceCarta < 0 || indiceCarta >= mao.size()) {
        std::cout << "Indice de carta invalido." << std::endl;
        return;
    }

    if (indiceZona < 0 || indiceZona >= campo.size() || campo[indiceZona].carta != nullptr) {
        std::cout << "Indice de zona invalido." << std::endl;
        return;
    }

    Carta cartaInvocada = mao[indiceCarta];
    cartaInvocada.posicao = posicao;
    cartaInvocada.faceParaBaixo = faceParaBaixo;

    campo[indiceZona].carta = new Carta(cartaInvocada);

    mao.erase(mao.begin() + indiceCarta);
    std::cout << "Carta " << cartaInvocada.nome << " foi invocada na zona " << indiceZona << " em posicao de " << posicao << "." << std::endl;
}

bool Jogador::todasZonasVazias() const {
    for (const auto& zona : campo) {
        if (zona.carta != nullptr) {
            return false;
        }
    }
    return true;
}

void Jogador::comprarCarta() {
    if (deck.empty()) {
        std::cout << "Não há mais cartas no deck para comprar." << std::endl;
        return;
    }
    mao.push_back(deck.back());
    deck.pop_back();
}

void Jogador::descartarCarta(int indiceCarta) {
    if (indiceCarta < 0 || indiceCarta >= mao.size()) {
        std::cout << "Indice de carta invalido." << std::endl;
        return;
    }
    cemiterio.push_back(mao[indiceCarta]);
    mao.erase(mao.begin() + indiceCarta);
}

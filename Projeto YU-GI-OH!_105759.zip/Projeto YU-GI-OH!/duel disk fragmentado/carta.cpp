#include "carta.h"
#include <iostream>

Carta::Carta(std::string nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito)
    : nome(nome), pontosATK(pontosATK), pontosDEF(pontosDEF), nivel(nivel), posicao("ataque"), faceParaBaixo(false), efeito(efeito) {}

void Carta::ativarEfeito() {
    if (efeito != nullptr) {
        efeito->ativar(this);
    }
}

void Carta::trocarPosicao() {
    if (posicao == "ataque") {
        posicao = "defesa";
    } else {
        posicao = "ataque";
    }
    std::cout << nome << " trocou para a posicao de " << posicao << "." << std::endl;
}

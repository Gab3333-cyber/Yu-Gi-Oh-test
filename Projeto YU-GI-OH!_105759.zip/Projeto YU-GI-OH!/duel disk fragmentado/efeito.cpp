#include "efeito.h"
#include "carta.h"
#include <iostream>

// Implementação de efeitos específicos aqui...
class EfeitoAumentoATK : public Efeito {
public:
    int aumento;
    EfeitoAumentoATK(int aumento) : aumento(aumento) {}
    void ativar(Carta* carta) override {
        carta->pontosATK += aumento;
        std::cout << "O ATK de " << carta->nome << " foi aumentado em " << aumento << " pontos." << std::endl;
    }
};

class EfeitoDiminuirATK : public Efeito {
public:
    int decremento;
    EfeitoDiminuirATK(int decremento) : decremento(decremento) {}
    void ativar(Carta* carta) override {
        carta->pontosATK -= decremento;
        std::cout << "O ATK de " << carta->nome << " foi diminuído em " << decremento << " pontos." << std::endl;
    }
};

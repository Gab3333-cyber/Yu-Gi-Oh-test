#ifndef EFEITO_H
#define EFEITO_H

class Carta; // Forward declaration

class Efeito {
public:
    virtual void ativar(Carta* carta) = 0;
};

#endif // EFEITO_H

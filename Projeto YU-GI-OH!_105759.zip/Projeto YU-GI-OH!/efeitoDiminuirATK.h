#apragma once
#include "efeito.h"

class EfeitoDiminuirATK : public Efeito {
public:
    EfeitoDiminuirATK(int diminuicao);
    void aplicar(Carta& carta) override;

private:
    int diminuicao;
};

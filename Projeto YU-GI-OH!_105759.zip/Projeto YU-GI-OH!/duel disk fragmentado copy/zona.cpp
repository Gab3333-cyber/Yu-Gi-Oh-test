// zona.cpp
#include "zona.h"

// Implement zone-related functionalities

Zona::Zona(const std::string& nome) : nome(nome) {}

const std::string& Zona::getNome() const {
    return nome;
}

void Zona::adicionarCarta(Carta* carta) {
    cartas.push_back(carta);
}

// zona.h
#ifndef ZONA_H
#define ZONA_H

#include <vector>
#include <string>
#include "carta.h"

class Zona {
public:
    Zona(const std::string& nome);
    const std::string& getNome() const;
    void adicionarCarta(Carta* carta);
private:
    std::string nome;
    std::vector<Carta*> cartas;
};

#endif // ZONA_H

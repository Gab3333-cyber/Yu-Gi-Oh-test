// jogo.h
#ifndef JOGO_H
#define JOGO_H

class Jogo {
public:
    void iniciar();
private:
    bool checarVencedor();
};

#endif // JOGO_H

// jogador.cpp
#include "jogador.h"

Jogador::Jogador(const std::string& nome) : nome(nome) {}

const std::string& Jogador::getNome() const {
    return nome;
}

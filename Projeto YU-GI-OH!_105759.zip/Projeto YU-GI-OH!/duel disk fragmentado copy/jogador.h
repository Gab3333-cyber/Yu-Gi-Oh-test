// jogador.h
#ifndef JOGADOR_H
#define JOGADOR_H

#include <string>

class Jogador {
public:
    Jogador(const std::string& nome);
    const std::string& getNome() const;
private:
    std::string nome;
};

#endif // JOGADOR_H

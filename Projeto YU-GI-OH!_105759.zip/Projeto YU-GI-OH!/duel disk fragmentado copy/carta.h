// carta.h
#ifndef CARTA_H
#define CARTA_H

#include <string>
#include "efeito.h"

class Carta {
public:
    Carta(const std::string& nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito = nullptr);
    void ativarEfeito();
    const std::string& getNome() const;

private:
    std::string nome;
    int pontosATK;
    int pontosDEF;
    int nivel;
    std::string posicao;
    bool faceParaBaixo;
    Efeito* efeito;
};

#endif // CARTA_H

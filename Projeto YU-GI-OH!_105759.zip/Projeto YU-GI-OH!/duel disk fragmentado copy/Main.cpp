// main.cpp
#include <iostream>
#include "jogo.h"

int main() {
    Jogo jogo;
    jogo.iniciar();
    return 0;
}

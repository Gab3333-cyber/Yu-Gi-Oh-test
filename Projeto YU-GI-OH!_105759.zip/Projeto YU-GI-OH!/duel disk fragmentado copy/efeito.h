// efeito.h
#ifndef EFEITO_H
#define EFEITO_H

#include "carta.h"
#include <string>

class Carta;

class Efeito {
public:
    virtual void ativar(Carta* carta) = 0;
};

class AumentarPV : public Efeito {
    int pv;
public:
    AumentarPV(int pv) : pv(pv) {}
    void ativar(Carta* carta) override;
};

class DanoDeEfeito : public Efeito {
    int dano;
public:
    DanoDeEfeito(int dano) : dano(dano) {}
    void ativar(Carta* carta) override;
};

class Compra : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class AumentarATK : public Efeito {
    int aumento;
public:
    AumentarATK(int aumento) : aumento(aumento) {}
    void ativar(Carta* carta) override;
};

class DiminuirATK : public Efeito {
    int decremento;
public:
    DiminuirATK(int decremento) : decremento(decremento) {}
    void ativar(Carta* carta) override;
};

class DestruirDeck : public Efeito {
    int quantidade;
public:
    DestruirDeck(int quantidade) : quantidade(quantidade) {}
    void ativar(Carta* carta) override;
};

class DestruirMagiaArmadilha : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class DestruirMonstro : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class MudarPosicao : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class DoCemiterioParaMao : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class DoCemiterioParaCampo : public Efeito {
public:
    void ativar(Carta* carta) override;
### `efeito.h` continued

```cpp
class Aposta : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class Banir : public Efeito {
public:
    void ativar(Carta* carta) override;
};

class InvocacaoEspecial : public Efeito {
public:
    void ativar(Carta* carta) override;
};

// Additional effect classes can be added here

#endif // EFEITO_H

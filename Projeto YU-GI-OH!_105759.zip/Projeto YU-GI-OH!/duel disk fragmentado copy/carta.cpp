// carta.cpp
#include "carta.h"

Carta::Carta(const std::string& nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito)
    : nome(nome), pontosATK(pontosATK), pontosDEF(pontosDEF), nivel(nivel), posicao("ataque"), faceParaBaixo(false), efeito(efeito) {}

void Carta::ativarEfeito() {
    if (efeito != nullptr) {
        efeito->ativar(this);
    }
}

const std::string& Carta::getNome() const {
    return nome;
}

// efeito.cpp
#include "efeito.h"
#include <iostream>

void AumentarPV::ativar(Carta* carta) {
    std::cout << "PV aumentou em " << pv << " pontos." << std::endl;
}

void DanoDeEfeito::ativar(Carta* carta) {
    std::cout << "Dano de efeito de " << dano << " pontos." << std::endl;
}

void Compra::ativar(Carta* carta) {
    std::cout << "Uma carta foi comprada." << std::endl;
}

void AumentarATK::ativar(Carta* carta) {
    carta->pontosATK += aumento;
    std::cout << "ATK de " << carta->getNome() << " aumentou em " << aumento << " pontos." << std::endl;
}

void DiminuirATK::ativar(Carta* carta) {
    carta->pontosATK -= decremento;
    std::cout << "ATK de " << carta->getNome() << " diminuiu em " << decremento << " pontos." << std::endl;
}

void DestruirDeck::ativar(Carta* carta) {
    std::cout << quantidade << " cartas foram destruídas do deck." << std::endl;
}

void DestruirMagiaArmadilha::ativar(Carta* carta) {
    std::cout << "Uma magia ou armadilha foi destruída." << std::endl;
}

void DestruirMonstro::ativar(Carta* carta) {
    std::cout << "Um monstro foi destruído." << std::endl;
}

void MudarPosicao::ativar(Carta* carta) {
    carta->posicao = (carta->posicao == "ataque") ? "defesa" : "ataque";
    std::cout << carta->getNome() << " mudou para posição de " << carta->posicao << "." << std::endl;
}

void DoCemiterioParaMao::ativar(Carta* carta) {
    std::cout << "Uma carta do cemitério foi movida para a mão." << std::endl;
}

void DoCemiterioParaCampo::ativar(Carta* carta) {
    std::cout << "Uma carta do cemitério foi movida para o campo." << std::endl;
}

void Aposta::ativar(Carta* carta) {
    srand(time(0));
    int resultado = rand() % 2;
    std::cout << "Aposta: " << (resultado ? "Coroa" : "Cara") << std::endl;
}

void Banir::ativar(Carta* carta) {
    std::cout << carta->getNome() << " foi banido." << std::endl;
}

void InvocacaoEspecial::ativar(Carta* carta) {
    std::cout << carta->getNome() << " foi invocado especialmente." << std::endl;
}

// Implement other effects as needed

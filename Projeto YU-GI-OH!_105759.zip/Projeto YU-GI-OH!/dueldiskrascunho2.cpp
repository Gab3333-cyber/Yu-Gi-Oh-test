#include <iostream>
#include <vector>
#include <string>
#include <set>

// Declaração antecipada das classes
class Carta;
class Jogador;

// Interface para efeitos das cartas
class Efeito {
public:
    virtual void ativar(Carta* carta) = 0;
    virtual ~Efeito() {} // Destrutor virtual para classes base polimórficas
};

// Classe base para cartas
class Carta {
public:
    std::string nome;
    int pontosATK;
    int pontosDEF;
    int nivel;
    std::string posicao;
    bool faceParaBaixo;
    Efeito* efeito;

    Carta(std::string nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito = nullptr)
        : nome(nome), pontosATK(pontosATK), pontosDEF(pontosDEF), nivel(nivel), posicao("ataque"), faceParaBaixo(false), efeito(efeito) {}

    // Ativar o efeito da carta, se houver
    void ativarEfeito() {
        if (efeito != nullptr) {
            efeito->ativar(this);
        }
    }

    // Trocar a posição da carta entre ataque e defesa
    void trocarPosicao() {
        posicao = (posicao == "ataque") ? "defesa" : "ataque";
        std::cout << nome << " trocou para a posição de " << posicao << "." << std::endl;
    }
};

// Efeito para aumentar o ATK de uma carta
class EfeitoAumentoATK : public Efeito {
public:
    int aumento;

    EfeitoAumentoATK(int aumento) : aumento(aumento) {}

    void ativar(Carta* carta) override {
        carta->pontosATK += aumento;
        std::cout << "O ATK de " << carta->nome << " foi aumentado em " << aumento << " pontos." << std::endl;
    }
};

// Efeito para diminuir o ATK de uma carta
class EfeitoDiminuirATK : public Efeito {
public:
    int decremento;

    EfeitoDiminuirATK(int decremento) : decremento(decremento) {}

    void ativar(Carta* carta) override {
        carta->pontosATK -= decremento;
        std::cout << "O ATK de " << carta->nome << " foi diminuído em " << decremento << " pontos." << std::endl;
    }
};

// Zona de jogo para armazenar uma carta
class Zona {
public:
    Carta* carta;

    Zona() : carta(nullptr) {}

    // Reiniciar a zona (remover a carta)
    void reiniciarZona() {
        carta = nullptr;
    }

    // Verificar se a zona está vazia
    bool vazia() const {
        return carta == nullptr;
    }
};

// Classe Jogador que controla o estado de um jogador
class Jogador {
public:
    std::vector<Carta> mao;
    std::vector<Zona> campo;
    std::vector<Carta> cemiterio;
    std::vector<Carta> deck;
    int pontosVida;

    Jogador() : pontosVida(8000), campo(5) {}

    // Adicionar uma carta à mão do jogador
    void adicionarCartaMao(const Carta& carta) {
        mao.push_back(carta);
    }

    // Exibir as cartas na mão do jogador
    void exibirMao() const {
        for (size_t i = 0; i < mao.size(); ++i) {
            std::cout << i << ": " << mao[i].nome << " (ATK: " << mao[i].pontosATK << ", DEF: " << mao[i].pontosDEF << ", Nível: " << mao[i].nivel << ")" << std::endl;
        }
    }

    // Exibir as cartas no campo do jogador
    void exibirCampo(int jogadorAtual) const {
        std::cout << "Campo do Jogador " << jogadorAtual << ":" << std::endl;
        for (size_t i = 0; i < campo.size(); ++i) {
            if (campo[i].carta != nullptr) {
                std::cout << "Zona " << i << ": " << campo[i].carta->nome << " (ATK: " << campo[i].carta->pontosATK << ", DEF: " << campo[i].carta->pontosDEF << ", Posição: " << campo[i].carta->posicao << ")" << std::endl;
            } else {
                std::cout << "Zona " << i << ": [vazia]" << std::endl;
            }
        }
    }

    // Invocar uma carta da mão para o campo
    void invocarCarta(int indiceCarta, int indiceZona, const std::string& posicao, int faceParaBaixo) {
        if (indiceCarta < 0 || indiceCarta >= mao.size()) {
            std::cout << "Índice de carta inválido." << std::endl;
            return;
        }

        if (indiceZona < 0 || indiceZona >= campo.size() || campo[indiceZona].carta != nullptr) {
            std::cout << "Índice de zona inválido." << std::endl;
            return;
        }

        Carta cartaInvocada = mao[indiceCarta];
        cartaInvocada.posicao = posicao;
        cartaInvocada.faceParaBaixo = faceParaBaixo;

        campo[indiceZona].carta = new Carta(cartaInvocada);

        mao.erase(mao.begin() + indiceCarta);
        std::cout << "Carta " << cartaInvocada.nome << " foi invocada na zona " << indiceZona << " em posição de " << posicao << "." << std::endl;
    }

    // Verificar se todas as zonas no campo do jogador estão vazias
    bool todasZonasVazias() const {
        for (const auto& zona : campo) {
            if (zona.carta != nullptr) {
                return false;
            }
        }
        return true;
    }

    // Comprar uma carta do deck
    void comprarCarta() {
        if (deck.empty()) {
            std::cout << "Não há mais cartas no deck para comprar." << std::endl;
            return;
        }
        mao.push_back(deck.back());
        deck.pop_back();
    }

    // Descartar uma carta da mão para o cemitério
    void descartarCarta(int indiceCarta) {
        if (indiceCarta < 0 || indiceCarta >= mao.size()) {
            std::cout << "Índice de carta inválido." << std::endl;
            return;
        }
        cemiterio.push_back(mao[indiceCarta]);
        mao.erase(mao.begin() + indiceCarta);
    }
};

// Classe Jogo que controla o estado do jogo e a execução das regras
class Jogo {
public:
    Jogador jogador1;
    Jogador jogador2;
    int jogadorAtual;
    int turno;
    std::set<int> monstrosAtacaram;

    Jogo() : jogadorAtual(1), turno(1) {}

    // Executar o jogo até que um jogador vença
    void executar() {
        while (jogador1.pontosVida > 0 && jogador2.pontosVida > 0) {
            std::cout << "Turno do Jogador " << jogadorAtual << std::endl;
            jogadorAtual == 1 ? jogador1.exibirCampo(jogadorAtual) : jogador2.exibirCampo(jogadorAtual);
            std::cout << "Mão do Jogador " << jogadorAtual << std::endl;
            jogadorAtual == 1 ? jogador1.exibirMao() : jogador2.exibirMao();

            std::string fase;
            if (turno == 1) {
                std::cout << "Fase de Compra. Pressione 'n' para a próxima fase: ";
                std::cin >> fase;
                if (fase == "n") {
                    if (jogadorAtual == 1) {
                        jogador1.comprarCarta();
                    } else {
                        jogador2.comprarCarta();
                    }
                    turno++;
                }
                continue;
            } else {
                std::cout << "Escolha a fase: 'm1' (Main Phase 1), 'b' (Battle Phase), 'm2' (Main Phase 2), 'e' (End Phase): ";
                std::cin >> fase;

                if (fase == "m1" || fase == "m2") {
                    escolherAcao(fase);
                } else if (fase == "b") {
                    ativarAtaque();
                } else if (fase == "e") {
                    finalizarTurno();
                }
            }
        }

        std::cout << "Jogo encerrado!" << std::endl;
    }

private:
    // Escolher ação para a fase principal
    void escolherAcao(const std::string& fase) {
        std::string acao;
        std::cout << "Escolha a ação: 'i' (Invocar carta), 't' (Trocar posição de carta), 'd' (Descartar carta): ";
        std::cin >> acao;

        if (acao == "i") {
            invocarCarta(fase);
        } else if (acao == "t") {
            trocarPosicaoCarta();
        } else if (acao == "d") {
            descartarCarta();
        }
    }

    // Invocar carta para o campo
    void invocarCarta(const std::string& fase) {
        int indiceCarta, indiceZona;
        std::string posicao;
        int faceParaBaixo;

        std::cout << "Escolha o índice da carta na mão: ";
        std::cin >> indiceCarta;

        std::cout << "Escolha a zona para invocação: ";
        std::cin >> indiceZona;

        std::cout << "Escolha a posição da carta ('ataque' ou 'defesa'): ";
        std::cin >> posicao;

        std::cout << "A carta será invocada virada para baixo? (0 - não, 1 - sim): ";
        std::cin >> faceParaBaixo;

        if (jogadorAtual == 1) {
            jogador1.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
        } else {
            jogador2.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
        }
    }

    // Trocar a posição de uma carta no campo
    void trocarPosicaoCarta() {
        int indiceZona;

        std::cout << "Escolha a zona para troca de posição: ";
        std::cin >> indiceZona;

        if (jogadorAtual == 1) {
            jogador1.campo[indiceZona].carta->trocarPosicao();
        } else {
            jogador2.campo[indiceZona].carta->trocarPosicao();
        }
    }

    // Descartar uma carta da mão
    void descartarCarta() {
        int indiceCarta;

        std::cout << "Escolha o índice da carta na mão para descartar: ";
        std::cin >> indiceCarta;

        if (jogadorAtual == 1) {
            jogador1.descartarCarta(indiceCarta);
        } else {
            jogador2.descartarCarta(indiceCarta);
        }
    }

    // Ativar a fase de ataque
    void ativarAtaque() {
        int indiceZonaAtacante, indiceZonaAtacada;

        std::cout << "Escolha a zona de ataque: ";
        std::cin >> indiceZonaAtacante;

        std::cout << "Escolha a zona para ataque: ";
        std::cin >> indiceZonaAtacada;

        if (jogadorAtual == 1) {
            atacar(jogador1, jogador2, indiceZonaAtacante, indiceZonaAtacada);
        } else {
            atacar(jogador2, jogador1, indiceZonaAtacante, indiceZonaAtacada);
        }
    }

    // Realizar o ataque entre cartas
    void atacar(Jogador& atacante, Jogador& atacado, int indiceZonaAtacante, int indiceZonaAtacada) {
        if (indiceZonaAtacante < 0 || indiceZonaAtacante >= atacante.campo.size() || atacante.campo[indiceZonaAtacante].carta == nullptr) {
            std::cout << "Zona de ataque inválida." << std::endl;
            return;
        }

        if (indiceZonaAtacada < 0 || indiceZonaAtacada >= atacado.campo.size() || atacado.campo[indiceZonaAtacada].carta == nullptr) {
            std::cout << "Zona de ataque inválida." << std::endl;
            return;
        }

        Carta* cartaAtacante = atacante.campo[indiceZonaAtacante].carta;
        Carta* cartaAtacada = atacado.campo[indiceZonaAtacada].carta;

        if (monstrosAtacaram.count(indiceZonaAtacante) > 0) {
            std::cout << "Este monstro já atacou neste turno." << std::endl;
            return;
        }

        monstrosAtacaram.insert(indiceZonaAtacante);

        if (cartaAtacante->posicao == "ataque" && cartaAtacada->posicao == "ataque") {
            if (cartaAtacante->pontosATK > cartaAtacada->pontosATK) {
                atacado.pontosVida -= (cartaAtacante->pontosATK - cartaAtacada->pontosATK);
                std::cout << "O Jogador " << atacado << " recebeu " << (cartaAtacante->pontosATK - cartaAtacada->pontosATK) << " de dano." << std::endl;
            } else if (cartaAtacante->pontosATK < cartaAtacada->pontosATK) {
                atacante.pontosVida -= (cartaAtacada->pontosATK - cartaAtacante->pontosATK);
                std::cout << "O Jogador " << atacante << " recebeu " << (cartaAtacada->pontosATK - cartaAtacante->pontosATK) << " de dano." << std::endl;
            } else {
                std::cout << "Os monstros destruíram uns aos outros." << std::endl;
            }
        } else if (cartaAtacante->posicao == "ataque" && cartaAtacada->posicao == "defesa") {
            if (cartaAtacante->pontosATK > cartaAtacada->pontosDEF) {
                atacado.pontosVida -= (cartaAtacante->pontosATK - cartaAtacada->pontosDEF);
                std::cout << "O Jogador " << atacado << " recebeu " << (cartaAtacante->pontosATK - cartaAtacada->pontosDEF) << " de dano." << std::endl;
            } else if (cartaAtacante->pontosATK < cartaAtacada->pontosDEF) {
                std::cout << "Nenhum dano foi causado ao Jogador " << atacado << "." << std::endl;
            } else {
                std::cout << "O monstro atacante foi destruído." << std::endl;
            }
        } else if (cartaAtacante->posicao == "defesa" && cartaAtacada->posicao == "ataque") {
            if (cartaAtacante->pontosDEF < cartaAtacada->pontosATK) {
                atacante.pontosVida -= (cartaAtacada->pontosATK - cartaAtacante->pontosDEF);
                std::cout << "O Jogador " << atacante << " recebeu " << (cartaAtacada->pontosATK - cartaAtacante->pontosDEF) << " de dano." << std::endl;
            } else if (cartaAtacante->pontosDEF > cartaAtacada->pontosATK) {
                std::cout << "Nenhum dano foi causado ao Jogador " << atacante << "." << std::endl;
            } else {
                std::cout << "O monstro atacante foi destruído." << std::endl;
            }
        }

        if (atacado.pontosVida <= 0) {
            std::cout << "O Jogador " << atacado << " foi derrotado!" << std::endl;
        }
    }

    // Finalizar o turno e preparar para o próximo
    void finalizarTurno() {
        monstrosAtacaram.clear();

        if (jogadorAtual == 1) {
            jogadorAtual = 2;
        } else {
            jogadorAtual = 1;
            turno++;
        }

        std::cout << "Turno do Jogador " << jogadorAtual << std::endl;
    }
};

int main() {
    // Exemplo de uso do jogo
    Jogo jogo;
    jogo.executar();

    return 0;
}

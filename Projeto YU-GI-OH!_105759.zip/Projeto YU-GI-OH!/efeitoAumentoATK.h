// efeitoAumentoATK.h
#apragma once
#include "efeito.h"

class efeitoAumentoATK : public Efeito {
public:
    efeitoAumentoATK(int aumento) : aumento(aumento) {}
    void aplicar(Carta& carta) override {
        carta.atk += aumento;
    }
private:
    int aumento;
};
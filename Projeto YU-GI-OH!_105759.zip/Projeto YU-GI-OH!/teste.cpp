#include <iostream>
#include <thread>
#include <chrono>

void countdown(int seconds) {
    for (int i = seconds; i > 0; --i) {
        std::cout << "Tempo restante: " << i << " segundos." << std::endl;
        sleep_for(std::chrono::seconds(1));
    }
    std::cout << "Tempo esgotado!" << std::endl;
}

int main() {
    int tempoTotal = 10; // Tempo total em segundos
    countdown(tempoTotal);

    return 0;
}

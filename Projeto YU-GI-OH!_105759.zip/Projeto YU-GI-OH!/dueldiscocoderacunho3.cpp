#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <cstdlib> // for rand()

// Forward declarations
class Carta;
class Efeito;

// Classe abstrata para efeitos das cartas
class Efeito {
public:
    virtual void ativar(Carta* carta) = 0;
};

// Classe principal para as cartas
class Carta {
public:
    std::string nome;
    int pontosATK;
    int pontosDEF;
    int nivel;
    std::string posicao;
    bool faceParaBaixo;
    Efeito* efeito;

    Carta(std::string nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito = nullptr)
        : nome(nome), pontosATK(pontosATK), pontosDEF(pontosDEF), nivel(nivel), posicao("ataque"), faceParaBaixo(false), efeito(efeito) {}

    // Ativar o efeito da carta
    void ativarEfeito() {
        if (efeito != nullptr) {
            efeito->ativar(this);
        }
    }

    // Trocar a posição da carta (ataque/defesa)
    void trocarPosicao() {
        if (posicao == "ataque") {
            posicao = "defesa";
        } else {
            posicao = "ataque";
        }
        std::cout << nome << " trocou para a posição de " << posicao << "." << std::endl;
    }
};

// Efeito específico: aumento de ATK
class EfeitoAumentoATK : public Efeito {
public:
    int aumento;

    EfeitoAumentoATK(int aumento) : aumento(aumento) {}

    void ativar(Carta* carta) override {
        carta->pontosATK += aumento;
        std::cout << "O ATK de " << carta->nome << " foi aumentado em " << aumento << " pontos." << std::endl;
    }
};

// Efeito específico: diminuição de ATK
class EfeitoDiminuirATK : public Efeito {
public:
    int decremento;

    EfeitoDiminuirATK(int decremento) : decremento(decremento) {}

    void ativar(Carta* carta) override {
        carta->pontosATK -= decremento;
        std::cout << "O ATK de " << carta->nome << " foi diminuído em " << decremento << " pontos." << std::endl;
    }
};

// Classe para representar uma zona de campo
class Zona {
public:
    Carta* carta; // Pode conter uma carta ou ser nulo

    Zona() : carta(nullptr) {}

    void reiniciarZona() {
        carta = nullptr;
    }

    bool vazia() const {
        return carta == nullptr;
    }
};

// Classe para representar um jogador
class Jogador {
public:
    std::vector<Carta> mao;       // Mão de cartas
    std::vector<Zona> campo;      // Zonas do campo
    std::vector<Carta> cemiterio; // Cartas no cemitério
    std::vector<Carta> deck;      // Baralho do jogador
    int pontosVida;               // Pontos de vida do jogador

    Jogador() : pontosVida(8000), campo(5) {}

    // Adicionar carta à mão
    void adicionarCartaMao(const Carta& carta) {
        mao.push_back(carta);
    }

    // Exibir as cartas na mão
    void exibirMao() const {
        for (size_t i = 0; i < mao.size(); ++i) {
            std::cout << i << ": " << mao[i].nome << " (ATK: " << mao[i].pontosATK << ", DEF: " << mao[i].pontosDEF << ", Nível: " << mao[i].nivel << ")" << std::endl;
        }
    }

    // Exibir as cartas no campo
    void exibirCampo(int jogadorAtual) const {
        std::cout << "Campo do Jogador " << jogadorAtual << ":" << std::endl;
        for (size_t i = 0; i < campo.size(); ++i) {
            if (campo[i].carta != nullptr) {
                std::cout << "Zona " << i << ": " << campo[i].carta->nome << " (ATK: " << campo[i].carta->pontosATK << ", DEF: " << campo[i].carta->pontosDEF << ", Posição: " << campo[i].carta->posicao << ")" << std::endl;
            } else {
                std::cout << "Zona " << i << ": [vazia]" << std::endl;
            }
        }
    }

    // Invocar carta no campo
    void invocarCarta(int indiceCarta, int indiceZona, const std::string& posicao, int faceParaBaixo) {
        if (indiceCarta < 0 || indiceCarta >= mao.size()) {
            std::cout << "Índice de carta inválido." << std::endl;
            return;
        }

        if (indiceZona < 0 || indiceZona >= campo.size() || campo[indiceZona].carta != nullptr) {
            std::cout << "Índice de zona inválido." << std::endl;
            return;
        }

        Carta cartaInvocada = mao[indiceCarta];
        cartaInvocada.posicao = posicao;
        cartaInvocada.faceParaBaixo = faceParaBaixo;

        campo[indiceZona].carta = new Carta(cartaInvocada);

        mao.erase(mao.begin() + indiceCarta);
        std::cout << "Carta " << cartaInvocada.nome << " foi invocada na zona " << indiceZona << " em posição de " << posicao << "." << std::endl;
    }

    // Verificar se todas as zonas do campo estão vazias
    bool todasZonasVazias() const {
        for (const auto& zona : campo) {
            if (zona.carta != nullptr) {
                return false;
            }
        }
        return true;
    }

    // Comprar carta do baralho
    void comprarCarta() {
        if (deck.empty()) {
            std::cout << "Não há mais cartas no deck para comprar." << std::endl;
            return;
        }
        mao.push_back(deck.back());
        deck.pop_back();
    }

    // Descartar carta da mão para o cemitério
    void descartarCarta(int indiceCarta) {
        if (indiceCarta < 0 || indiceCarta >= mao.size()) {
            std::cout << "Índice de carta inválido." << std::endl;
            return;
        }
        cemiterio.push_back(mao[indiceCarta]);
        mao.erase(mao.begin() + indiceCarta);
    }
};

// Classe principal do jogo
class Jogo {
public:
    Jogador jogador1;
    Jogador jogador2;
    int jogadorAtual;
    int turno;
    std::set<int> monstrosAtacaram;

    Jogo() : jogadorAtual(1), turno(1) {}

    // Método principal para executar o jogo
    void executar() {
        while (jogador1.pontosVida > 0 && jogador2.pontosVida > 0) {
            std::cout << "Turno do Jogador " << jogadorAtual << std::endl;
            jogadorAtual == 1 ? jogador1.exibirCampo(jogadorAtual) : jogador2.exibirCampo(jogadorAtual);
            std::cout << "Mão do Jogador " << jogadorAtual << std::endl;
            jogadorAtual == 1 ? jogador1.exibirMao() : jogador2.exibirMao();

            std::string fase;
            if (turno == 1) {
                std::cout << "Fase de Compra. Pressione n para a próxima fase: ";
                std::cin >> fase;
                if (fase == "n") {
                    if (jogadorAtual == 1) {
                        jogador1.comprarCarta();
                    } else {
                        jogador2.comprarCarta();
                    }
                    turno++;
                }
                continue;
            } else {
                std::cout << "Escolha a fase: m1 (Main Phase 1), b (Battle Phase), m2 (Main Phase 2), e (End Phase): ";
                std::cin >> fase;

                if (fase == "m1" || fase == "m2") {
                    std::string acao;
                    std::cout << "Escolha a ação: i (invocar), p (trocar posição), a (ativar efeito), n (próxima fase): ";
                    std::cin >> acao;

                    if (acao == "i") {
                        invocarCarta();
                    } else if (acao == "p") {
                        trocarPosicaoCarta();
                    } else if (acao == "a") {
                        ativarEfeitoCarta();
                    } else if (acao == "n") {
                        turno++;
                    } else {
                        std::cout << "Ação inválida." << std::endl;
                    }
                } else if (fase == "b") {
                    atacar();
                } else if (fase == "e") {
                    turno++;
                } else {
                    std::cout << "Fase inválida." << std::endl;
                }
            }

            // Troca de jogador
            if (jogadorAtual == 1) {
                jogadorAtual = 2;
            } else {
                jogadorAtual = 1;
            }
        }

        std::cout << "Fim do Jogo!" << std::endl;
        std::cout << "Jogador " << (jogador1.pontosVida <= 0 ? 2 : 1) << " venceu!" << std::endl;
    }

private:
    // Método para invocar uma carta
    void invocarCarta() {
        int indiceCarta, indiceZona;
        std::string posicao;
        int faceParaBaixo;

        std::cout << "Escolha o índice da carta na mão: ";
        std::cin >> indiceCarta;
        std::cout << "Escolha o índice da zona de campo: ";
        std::cin >> indiceZona;
        std::cout << "Escolha a posição (ataque/defesa): ";
        std::cin >> posicao;
        std::cout << "Face para baixo? (0 - não, 1 - sim): ";
        std::cin >> faceParaBaixo;

        if (jogadorAtual == 1) {
            jogador1.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
        } else {
            jogador2.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
        }
    }

    // Método para trocar a posição de uma carta
    void trocarPosicaoCarta() {
        int indiceZona;

        std::cout << "Escolha o índice da zona de campo: ";
        std::cin >> indiceZona;

        if (jogadorAtual == 1) {
            jogador1.campo[indiceZona].carta->trocarPosicao();
        } else {
            jogador2.campo[indiceZona].carta->trocarPosicao();
        }
    }

    // Método para ativar o efeito de uma carta
    void ativarEfeitoCarta() {
        int indiceZona;

        std::cout << "Escolha o índice da zona de campo: ";
        std::cin >> indiceZona;

        if (jogadorAtual == 1) {
            jogador1.campo[indiceZona].carta->ativarEfeito();
        } else {
            jogador2.campo[indiceZona].carta->ativarEfeito();
        }
    }

    // Método para realizar um ataque entre cartas
    void atacar() {
        int zonaAtacante, zonaAlvo;

        std::cout << "Escolha o índice da zona de ataque: ";
        std::cin >> zonaAtacante;
        std::cout << "Escolha o índice da zona alvo: ";
        std::cin >> zonaAlvo;

        if (jogadorAtual == 1) {
            realizarAtaque(jogador1.campo[zonaAtacante], jogador2.campo[zonaAlvo]);
        } else {
            realizarAtaque(jogador2.campo[zonaAtacante], jogador1.campo[zonaAlvo]);
        }
    }

    // Método para realizar um ataque entre cartas
    void realizarAtaque(Zona& zonaAtacante, Zona& zonaAlvo) {
        if (zonaAtacante.carta == nullptr || zonaAlvo.carta == nullptr) {
            std::cout << "Não é possível realizar o ataque." << std::endl;
            return;
        }

        if (monstrosAtacaram.find(zonaAtacante.carta->nivel) != monstrosAtacaram.end()) {
            std::cout << "Este monstro já atacou neste turno." << std::endl;
            return;
        }

        monstrosAtacaram.insert(zonaAtacante.carta->nivel);

        int diferencaATK = zonaAtacante.carta->pontosATK - zonaAlvo.carta->pontosATK;

        if (diferencaATK > 0) {
            // Zona alvo destruída
            std::cout << zonaAtacante.carta->nome << " destruiu " << zonaAlvo.carta->nome << "." << std::endl;
            zonaAlvo.carta = nullptr;
        } else if (diferencaATK < 0) {
            // Zona atacante destruída
            std::cout << zonaAlvo.carta->nome << " destruiu " << zonaAtacante.carta->nome << "." << std::endl;
            zonaAtacante.carta = nullptr;
        } else {
            // Ambas as cartas são destruídas
            std::cout << zonaAtacante.carta->nome << " e " << zonaAlvo.carta->nome << " foram destruídas." << std::endl;
            zonaAtacante.carta = nullptr;
            zonaAlvo.carta = nullptr;
        }
    }
};

int main() {
    Jogo jogo;
    jogo.executar();

    return 0;
}

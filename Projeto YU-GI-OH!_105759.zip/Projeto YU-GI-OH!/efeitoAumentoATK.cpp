#include "efeitoAumentoATK.h"
#include "carta.h"

EfeitoAumentoATK::EfeitoAumentoATK(int aumento) : aumento(aumento) {}

void EfeitoAumentoATK::aplicar(Carta& carta) {
    carta.pontosATK += aumento;
}

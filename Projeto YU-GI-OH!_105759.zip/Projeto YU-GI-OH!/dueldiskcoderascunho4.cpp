#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <unordered_set>

class Carta {
public:
    std::string nome;
    int pontosATK;
    int pontosDEF;
    int nivel;
    std::string posicao;
    bool faceParaBaixo;

    Carta(std::string n, int atk, int def, int lvl)
        : nome(n), pontosATK(atk), pontosDEF(def), nivel(lvl), faceParaBaixo(false) {}

    void exibirCarta(int jogadorAtual, int jogadorVisualizando) {
        if (jogadorAtual == jogadorVisualizando || !faceParaBaixo) {
            std::cout << "Nome: " << nome << std::endl;
            std::cout << "ATK: " << pontosATK << std::endl;
            std::cout << "DEF: " << pontosDEF << std::endl;
            std::cout << "Nivel: " << nivel << std::endl;
            std::cout << "Posicao: " << posicao << std::endl;
        } else {
            std::cout << "Carta virada para baixo" << std::endl;
            std::cout << "Posicao: " << posicao << std::endl;
        }
    }

    void trocarPosicao() {
        if (posicao == "ataque") {
            posicao = "defesa";
            faceParaBaixo = false;
        } else if (posicao == "defesa" && faceParaBaixo) {
            posicao = "ataque";
            faceParaBaixo = false;
        } else {
            posicao = "ataque";
        }
    }
};

class Zona {
public:
    Carta* carta;
    std::string posicao;
    bool faceParaBaixo;

    Zona() : carta(nullptr), faceParaBaixo(false) {}

    void colocarCarta(Carta* c, const std::string& pos, bool faceDown) {
        carta = c;
        posicao = pos;
        faceParaBaixo = faceDown;
    }

    void reiniciarZona() {
        carta = nullptr;
        posicao = "";
        faceParaBaixo = false;
    }

    void exibirZona(int jogadorAtual, int jogadorVisualizando) {
        if (carta != nullptr) {
            carta->exibirCarta(jogadorAtual, jogadorVisualizando);
        } else {
            std::cout << "Zona vazia" << std::endl;
        }
    }
};

class Jogador {
public:
    std::string nome;
    int pontosVida;
    std::vector<Carta> mao;
    std::vector<Zona> campo;

    Jogador(std::string n) : nome(n), pontosVida(8000), campo(5) {}

    void adicionarCartaMao(Carta carta) {
        mao.push_back(carta);
    }

    void invocarCarta(int indiceCarta, int indiceZona, const std::string& posicao, bool faceParaBaixo) {
        if (indiceCarta < 0 || indiceCarta >= mao.size() || indiceZona < 0 || indiceZona >= campo.size()) {
            std::cout << "Indice invalido." << std::endl;
            return;
        }
        Carta* carta = new Carta(mao[indiceCarta]);
        campo[indiceZona].colocarCarta(carta, posicao, faceParaBaixo);
        mao.erase(mao.begin() + indiceCarta);
    }

    void exibirMao() {
        for (int i = 0; i < mao.size(); ++i) {
            std::cout << "Indice " << i << ":" << std::endl;
            mao[i].exibirCarta(1, 1); // Sempre exibir a mao completa
        }
    }

    void exibirCampo(int jogadorVisualizando) {
        for (int i = 0; i < campo.size(); ++i) {
            std::cout << "Zona " << i << ":" << std::endl;
            campo[i].exibirZona(1, jogadorVisualizando);
        }
    }

    bool todasZonasVazias() {
        for (const auto& zona : campo) {
            if (zona.carta != nullptr) {
                return false;
            }
        }
        return true;
    }
};

enum Fase { MAIN1, BATTLE, MAIN2, END };

class Jogo {
public:
    Jogador jogador1;
    Jogador jogador2;
    Fase faseAtual;
    int jogadorAtual;
    std::unordered_set<int> monstrosAtacaram;
    bool invocacaoFeita;

    Jogo() : jogador1("Yugi"), jogador2("Kaiba"), faseAtual(MAIN1), jogadorAtual(1), invocacaoFeita(false) {
        // Adicionar cartas de Yugi ao jogador 1 (Yugi)
        jogador1.adicionarCartaMao(Carta("Dark Magician", 2500, 2100, 7));
        jogador1.adicionarCartaMao(Carta("Gaia The Fierce Knight", 2300, 2100, 7));
        jogador1.adicionarCartaMao(Carta("Summoned Skull", 2500, 1200, 6));
        jogador1.adicionarCartaMao(Carta("Kuriboh", 300, 200, 1));
        jogador1.adicionarCartaMao(Carta("Catapult Turtle", 1000, 2000, 5));

        // Adicionar cartas de Kaiba ao jogador 2 (Kaiba)
        jogador2.adicionarCartaMao(Carta("Blue-Eyes White Dragon", 3000, 2500, 8));
        jogador2.adicionarCartaMao(Carta("XYZ-Dragon Cannon", 2800, 2600, 7));
        jogador2.adicionarCartaMao(Carta("Vorse Raider", 1900, 1200, 4));
        jogador2.adicionarCartaMao(Carta("Battle Ox", 1700, 1000, 4));
        jogador2.adicionarCartaMao(Carta("Saggi the Dark Clown", 600, 1500, 3));
    }

    void proximaFase() {
        if (faseAtual == MAIN1) {
            faseAtual = BATTLE;
        } else if (faseAtual == BATTLE) {
            faseAtual = MAIN2;
        } else if (faseAtual == MAIN2) {
            faseAtual = END;
        } else if (faseAtual == END) {
            faseAtual = MAIN1;
            jogadorAtual = (jogadorAtual == 1) ? 2 : 1;
            monstrosAtacaram.clear();
            invocacaoFeita = false;
        }
    }

    void executar() {
        while (true) {
            std::cout << "Fase Atual: " << obterNomeFase() << std::endl;

            if (faseAtual == MAIN1 || faseAtual == MAIN2) {
                std::cout << "Pressione 's' para invocar monstro, 'S' para trocar posicao, 'n' para proxima fase, 'f' para fase final" << std::endl;
                char comando;
                std::cin >> comando;
                if (comando == 's') {
                    if (invocacaoFeita) {
                        std::cout << "Voce ja invocou esse turno" << std::endl;
                    } else {
                        invocarMonstro();
                        invocacaoFeita = true;
                    }
                } else if (comando == 'S') {
                    trocarPosicaoMonstro();
                } else if (comando == 'n') {
                    proximaFase();
                } else if (comando == 'f') {
                    faseAtual = END;
                    proximaFase();
                }
            } else if (faseAtual == BATTLE) {
                std::cout << "Pressione 'd' para ativar ataque, 'n' para proxima fase, 'f' para fase final" << std::endl;
                char comando;
                std::cin >> comando;
                if (comando == 'd') {
                    ativarAtaque();
                } else if (comando == 'n') {
                    proximaFase();
                } else if (comando == 'f') {
                    faseAtual = END;
                    proximaFase();
                }
            }

            exibirPontosVida();
        }
    }

    std::string obterNomeFase() {
        switch (faseAtual) {
            case MAIN1: return "Main Phase 1";
            case BATTLE: return "Battle Phase";
            case MAIN2: return "Main Phase 2";
            case END: return "End Phase";
        }
        return "";
    }

    void exibirPontosVida() {
        std::cout << jogador1.nome << " Pontos de Vida: " << jogador1.pontosVida << std::endl;
        std::cout << jogador2.nome << " Pontos de Vida: " << jogador2.pontosVida << std::endl;
    }

    void invocarMonstro() {
        Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
        jogador.exibirMao();

        std::cout << "Escolha uma carta da mao para invocar: ";
        int indiceCarta;
        std::cin >> indiceCarta;

        std::cout << "Escolha uma zona do campo para invocar: ";
        int indiceZona;
        std::cin >> indiceZona;

        std::cout << "Selecione a posicao do monstro: " << std::endl;
        std::cout << "1 - Ataque" << std::endl;
        std::cout << "2 - Defesa (Face para baixo)" << std::endl;

        int escolha;
        std::cin >> escolha;

        std::string posicao = "ataque";
        bool faceParaBaixo = false;
        if (escolha == 1) {
            posicao = "ataque";
            faceParaBaixo = false;
        } else if (escolha == 2) {
            posicao = "defesa";
            faceParaBaixo = true;
        }

        jogador.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
    }

    void trocarPosicaoMonstro() {
        Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
        jogador.exibirCampo(jogadorAtual);

        std::cout << "Escolha uma zona do campo para trocar posicao: ";
        int indiceZona;
        std::cin >> indiceZona;

        Zona& zona = jogador.campo[indiceZona];
        if (zona.carta != nullptr) {
            zona.carta->trocarPosicao();
        } else {
            std::cout << "Zona vazia." << std::endl;
        }
    }

    void ativarAtaque() {
        Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
        jogador.exibirCampo(jogadorAtual);

        std::cout << "Escolha uma zona do campo para atacar: ";
        int indiceZonaAtacante;
        std::cin >> indiceZonaAtacante;

        Zona& zonaAtacante = jogador.campo[indiceZonaAtacante];
        if (zonaAtacante.carta == nullptr || zonaAtacante.carta->posicao == "defesa") {
            std::cout << "Nao ha monstro para atacar ou monstro na posicao de defesa." << std::endl;
            return;
        }

        std::cout << "Escolha uma zona do campo adversario para atacar: ";
        int indiceZonaDefensora;
        std::cin >> indiceZonaDefensora;

        Jogador& adversario = (jogadorAtual == 1) ? jogador2 : jogador1;
        Zona& zonaDefensora = adversario.campo[indiceZonaDefensora];

        if (zonaDefensora.carta == nullptr) {
            atacarDireto(jogador, zonaAtacante);
        } else {
            atacarMonstro(jogador, zonaAtacante, adversario, zonaDefensora);
        }
    }

    void atacarDireto(Jogador& atacante, Zona& zonaAtacante) {
        Jogador& adversario = (jogadorAtual == 1) ? jogador2 : jogador1;
        adversario.pontosVida -= zonaAtacante.carta->pontosATK;
        std::cout << "Ataque direto! " << adversario.nome << " perdeu " << zonaAtacante.carta->pontosATK << " pontos de vida." << std::endl;
    }

    void atacarMonstro(Jogador& atacante, Zona& zonaAtacante, Jogador& defensor, Zona& zonaDefensora) {
        if (monstrosAtacaram.find(zonaAtacante.carta->nivel) != monstrosAtacaram.end()) {
            std::cout << "Este monstro ja atacou este turno." << std::endl;
            return;
        }

        if (zonaAtacante.carta->pontosATK > zonaDefensora.carta->pontosDEF) {
            std::cout << "Ataque bem sucedido! " << defensor.nome << " perdeu " << (zonaAtacante.carta->pontosATK - zonaDefensora.carta->pontosDEF) << " pontos de vida." << std::endl;
            defensor.pontosVida -= (zonaAtacante.carta->pontosATK - zonaDefensora.carta->pontosDEF);
        } else if (zonaAtacante.carta->pontosATK < zonaDefensora.carta->pontosDEF) {
            std::cout << "Ataque mal sucedido! " << atacante.nome << " perdeu " << (zonaDefensora.carta->pontosDEF - zonaAtacante.carta->pontosATK) << " pontos de vida." << std::endl;
            atacante.pontosVida -= (zonaDefensora.carta->pontosDEF - zonaAtacante.carta->pontosATK);
        } else {
            std::cout << "Empate no ataque! Nenhum jogador perdeu pontos de vida." << std::endl;
        }

        monstrosAtacaram.insert(zonaAtacante.carta->nivel);
    }
};

int main() {
    Jogo jogo;
    jogo.executar();

    return 0;
}

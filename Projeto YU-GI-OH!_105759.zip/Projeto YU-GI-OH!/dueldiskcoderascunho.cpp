#include <iostream>
#include <vector>
#include <string>
#include <set>

class Efeito {
public:
    virtual void ativar(class Carta* carta) = 0;
};

class Carta {
public:
    std::string nome;
    int pontosATK;
    int pontosDEF;
    int nivel;
    std::string posicao;
    bool faceParaBaixo;
    Efeito* efeito;

    Carta(std::string nome, int pontosATK, int pontosDEF, int nivel, Efeito* efeito = nullptr)
        : nome(nome), pontosATK(pontosATK), pontosDEF(pontosDEF), nivel(nivel), posicao("ataque"), faceParaBaixo(false), efeito(efeito) {}

    void ativarEfeito() {
        if (efeito != nullptr) {
            efeito->ativar(this);
        }
    }

    void trocarPosicao() {
        if (posicao == "ataque") {
            posicao = "defesa";
        } else {
            posicao = "ataque";
        }
        std::cout << nome << " trocou para a posicao de " << posicao << "." << std::endl;
    }
};

class EfeitoAumentoATK : public Efeito {
public:
    int aumento;

    EfeitoAumentoATK(int aumento) : aumento(aumento) {}

    void ativar(Carta* carta) override {
        carta->pontosATK += aumento;
        std::cout << "O ATK de " << carta->nome << " foi aumentado em " << aumento << " pontos." << std::endl;
    }
};

class EfeitoDiminuirATK : public Efeito {
public:
    int decremento;

    EfeitoDiminuirATK(int decremento) : decremento(decremento) {}

    void ativar(Carta* carta) override {
        carta->pontosATK -= decremento;
        std::cout << "O ATK de " << carta->nome << " foi diminuído em " << decremento << " pontos." << std::endl;
    }
};

class Zona {
public:
    Carta* carta;

    Zona() : carta(nullptr) {}

    void reiniciarZona() {
        carta = nullptr;
    }

    bool vazia() const {
        return carta == nullptr;
    }
};

class Jogador {
public:
    std::vector<Carta> mao;
    std::vector<Zona> campo;
    std::vector<Carta> cemiterio;
    std::vector<Carta> deck;
    int pontosVida;

    Jogador() : pontosVida(8000), campo(5) {}

    void adicionarCartaMao(const Carta& carta) {
        mao.push_back(carta);
    }

    void exibirMao() const {
        for (size_t i = 0; i < mao.size(); ++i) {
            std::cout << i << ": " << mao[i].nome << " (ATK: " << mao[i].pontosATK << ", DEF: " << mao[i].pontosDEF << ", Nivel: " << mao[i].nivel << ")" << std::endl;
        }
    }

    void exibirCampo(int jogadorAtual) const {
        std::cout << "Campo do Jogador " << jogadorAtual << ":" << std::endl;
        for (size_t i = 0; i < campo.size(); ++i) {
            if (campo[i].carta != nullptr) {
                std::cout << "Zona " << i << ": " << campo[i].carta->nome << " (ATK: " << campo[i].carta->pontosATK << ", DEF: " << campo[i].carta->pontosDEF << ", Posicao: " << campo[i].carta->posicao << ")" << std::endl;
            } else {
                std::cout << "Zona " << i << ": [vazia]" << std::endl;
            }
        }
    }

    void invocarCarta(int indiceCarta, int indiceZona, const std::string& posicao, int faceParaBaixo) {
        if (indiceCarta < 0 || indiceCarta >= mao.size()) {
            std::cout << "Indice de carta invalido." << std::endl;
            return;
        }

        if (indiceZona < 0 || indiceZona >= campo.size() || campo[indiceZona].carta != nullptr) {
            std::cout << "Indice de zona invalido." << std::endl;
            return;
        }

        Carta cartaInvocada = mao[indiceCarta];
        cartaInvocada.posicao = posicao;
        cartaInvocada.faceParaBaixo = faceParaBaixo;

        campo[indiceZona].carta = new Carta(cartaInvocada);

        mao.erase(mao.begin() + indiceCarta);
        std::cout << "Carta " << cartaInvocada.nome << " foi invocada na zona " << indiceZona << " em posicao de " << posicao << "." << std::endl;
    }

    bool todasZonasVazias() const {
        for (const auto& zona : campo) {
            if (zona.carta != nullptr) {
                return false;
            }
        }
        return true;
    }

    void comprarCarta() {
        if (deck.empty()) {
            std::cout << "Não há mais cartas no deck para comprar." << std::endl;
            return;
        }
        mao.push_back(deck.back());
        deck.pop_back();
    }

    void descartarCarta(int indiceCarta) {
        if (indiceCarta < 0 || indiceCarta >= mao.size()) {
            std::cout << "Indice de carta invalido." << std::endl;
            return;
        }
        cemiterio.push_back(mao[indiceCarta]);
        mao.erase(mao.begin() + indiceCarta);
    }
};

class Jogo {
public:
    Jogador jogador1;
    Jogador jogador2;
    int jogadorAtual;
    int turno;
    std::set<int> monstrosAtacaram;

    Jogo() : jogadorAtual(1), turno(1) {}

    void executar() {
        while (jogador1.pontosVida > 0 && jogador2.pontosVida > 0) {
            std::cout << "Turno do Jogador " << jogadorAtual << std::endl;
            jogadorAtual == 1 ? jogador1.exibirCampo(jogadorAtual) : jogador2.exibirCampo(jogadorAtual);
            std::cout << "Mao do Jogador " << jogadorAtual << std::endl;
            jogadorAtual == 1 ? jogador1.exibirMao() : jogador2.exibirMao();

            std::string fase;
            if (turno == 1) {
                std::cout << "Fase de Compra. Pressione n para a proxima fase: ";
                std::cin >> fase;
                if (fase == "n") {
                    if (jogadorAtual == 1) {
                        jogador1.comprarCarta();
                    } else {
                        jogador2.comprarCarta();
                    }
                    turno++;
                }
                continue;
            } else {
                std::cout << "Escolha a fase: m1 (Main Phase 1), b (Battle Phase), m2 (Main Phase 2), e (End Phase): ";
                std::cin >> fase;

                if (fase == "m1" || fase == "m2") {
                    std::string acao;
                    std::cout << "Escolha a acao: i (invocar), p (trocar posicao), a (ativar efeito), n (proxima fase): ";
                    std::cin >> acao;

                    if (acao == "i") {
                        invocarMonstro();
                    } else if (acao == "p") {
                        trocarPosicaoMonstro();
                    } else if (acao == "a") {
                        ativarEfeito();
                    } else if (acao == "n") {
                        if (fase == "m1") {
                            continue;
                        } else {
                            finalizarTurno();
                        }
                    }
                } else if (fase == "b") {
                    ativarAtaque();
                } else if (fase == "e") {
                    finalizarTurno();
                }
            }
        }

        std::cout << "Jogo encerrado!" << std::endl;
    }

    void finalizarTurno() {
        jogadorAtual = (jogadorAtual == 1) ? 2 : 1;
        turno++;
        monstrosAtacaram.clear();
        if (jogadorAtual == 1) {
            jogador1.comprarCarta();
        } else {
            jogador2.comprarCarta();
        }
    }

    void invocarMonstro() {
        int indiceCarta, indiceZona, faceParaBaixo;
        std::string posicao;
        std::cout << "Escolha a carta da mao para invocar (indice): ";
        std::cin >> indiceCarta;
        std::cout << "Escolha a zona do campo para invocar (indice): ";
        std::cin >> indiceZona;
        std::cout << "Escolha a posicao (ataque/defesa): ";
        std::cin >> posicao;
        std::cout << "Invocar com a face para baixo? (1 para sim, 0 para nao): ";
        std::cin >> faceParaBaixo;

        Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
        jogador.invocarCarta(indiceCarta, indiceZona, posicao, faceParaBaixo);
    }

    void trocarPosicaoMonstro() {
        int indiceZona;
        std::cout << "Escolha a zona do monstro para trocar posicao (indice): ";
        std::cin >> indiceZona;

        Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
        if (indiceZona < 0 || indiceZona >= jogador.campo.size() || jogador.campo[indiceZona].carta == nullptr) {
            std::cout << "Indice de zona invalido." << std::endl;
            return;
        }

        jogador.campo[indiceZona].carta->trocarPosicao();
    }

    void ativarEfeito() {
        int indiceZona;
        std::cout << "Escolha a zona do monstro para ativar efeito (indice): ";
        std::cin >> indiceZona;

        Jogador& jogador = (jogadorAtual == 1) ? jogador1 : jogador2;
        if (indiceZona < 0 || indiceZona >= jogador.campo.size() || jogador.campo[indiceZona].carta == nullptr) {
            std::cout << "Indice de zona invalido." << std::endl;
            return;
        }

        jogador.campo[indiceZona].carta->ativarEfeito();
    }

    void ativarAtaque() {
        int indiceAtacante, indiceDefensor;
        std::cout << "Escolha a zona do monstro atacante (indice): ";
        std::cin >> indiceAtacante;

        Jogador& jogadorAtacante = (jogadorAtual == 1) ? jogador1 : jogador2;
        Jogador& jogadorDefensor = (jogadorAtual == 1) ? jogador2 : jogador1;

        if (indiceAtacante < 0 || indiceAtacante >= jogadorAtacante.campo.size() || jogadorAtacante.campo[indiceAtacante].carta == nullptr) {
            std::cout << "Indice de zona invalido." << std::endl;
            return;
        }

        if (monstrosAtacaram.find(indiceAtacante) != monstrosAtacaram.end()) {
            std::cout << "Este monstro ja atacou neste turno." << std::endl;
            return;
        }

        if (jogadorDefensor.todasZonasVazias()) {
            std::cout << "Nao ha monstros no campo do adversario. Ataque direto!" << std::endl;
            jogadorDefensor.pontosVida -= jogadorAtacante.campo[indiceAtacante].carta->pontosATK;
            if (jogadorDefensor.pontosVida < 0) {
                jogadorDefensor.pontosVida = 0;
            }
            std::cout << "Pontos de Vida do Jogador " << (jogadorAtual == 1 ? 2 : 1) << ": " << jogadorDefensor.pontosVida << std::endl;
            monstrosAtacaram.insert(indiceAtacante);
            return;
        }

        std::cout << "Escolha a zona do monstro defensor (indice): ";
        std::cin >> indiceDefensor;

        if (indiceDefensor < 0 || indiceDefensor >= jogadorDefensor.campo.size() || jogadorDefensor.campo[indiceDefensor].carta == nullptr) {
            std::cout << "Indice de zona invalido." << std::endl;
            return;
        }

        Carta* atacante = jogadorAtacante.campo[indiceAtacante].carta;
        Carta* defensor = jogadorDefensor.campo[indiceDefensor].carta;

        if (atacante->pontosATK > defensor->pontosDEF) {
            std::cout << atacante->nome << " (ATK: " << atacante->pontosATK << ") destruiu " << defensor->nome << " (DEF: " << defensor->pontosDEF << ")." << std::endl;
            jogadorDefensor.cemiterio.push_back(*defensor);
            jogadorDefensor.campo[indiceDefensor].reiniciarZona();
        } else if (atacante->pontosATK < defensor->pontosDEF) {
            std::cout << atacante->nome << " (ATK: " << atacante->pontosATK << ") foi destruido ao atacar " << defensor->nome << " (DEF: " << defensor->pontosDEF << ")." << std::endl;
            jogadorAtacante.cemiterio.push_back(*atacante);
            jogadorAtacante.campo[indiceAtacante].reiniciarZona();
        } else {
            std::cout << "O ataque resultou em um empate. Ambos os monstros foram destruídos." << std::endl;
            jogadorAtacante.cemiterio.push_back(*atacante);
            jogadorAtacante.campo[indiceAtacante].reiniciarZona();
            jogadorDefensor.cemiterio.push_back(*defensor);
            jogadorDefensor.campo[indiceDefensor].reiniciarZona();
        }

        monstrosAtacaram.insert(indiceAtacante);
    }
};

int main() {
    Jogo jogo;

    // Exemplo de inicializacao de decks
    jogo.jogador1.deck = {
        Carta("Dragão Branco de Olhos Azuis", 3000, 2500, 8),
        Carta("Dragão Negro de Olhos Vermelhos", 2400, 2000, 7),
        Carta("Mago Negro", 2500, 2100, 7, new EfeitoAumentoATK(500))
    };

    jogo.jogador2.deck = {
        Carta("Invocador das Trevas", 2000, 1700, 6, new EfeitoDiminuirATK(300)),
        Carta("Caveira Convocada", 2500, 1200, 6),
        Carta("Gigante de Pedra", 2000, 2300, 5)
    };

    jogo.jogador1.comprarCarta();
    jogo.jogador2.comprarCarta();
    jogo.jogador1.comprarCarta();
    jogo.jogador2.comprarCarta();

    jogo.executar();
    
    return 0;
}
